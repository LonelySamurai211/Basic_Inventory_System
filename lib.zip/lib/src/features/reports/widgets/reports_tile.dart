import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../notifications/notifications_list_provider.dart';

class ReportTile extends ConsumerWidget {
  final Map<String, dynamic> data;

  const ReportTile({super.key, required this.data});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListTile(
      leading: const Icon(Icons.receipt_long),
      title: Text(data["title"] ?? ""),
      subtitle: Text(data["message"] ?? ""),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => ReportDetailsDialog(data: data),
              );
            },
            child: const Text("View details"),
          ),
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Delete Report'),
                  content: const Text('Are you sure you want to delete this report?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(false),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(true),
                      child: const Text('Delete'),
                    ),
                  ],
                ),
              );
              if (confirmed == true) {
                final id = data['id']?.toString();
                if (id != null) {
                  await ref.read(notificationsListProvider.notifier).delete(id);
                }
              }
            },
          ),
        ],
      ),
    );
  }
}

//
// ─────────────────────────────────────────────────────────────
//   REPORT DETAILS DIALOG
// ─────────────────────────────────────────────────────────────
//

class ReportDetailsDialog extends StatelessWidget {
  final Map<String, dynamic> data;

  const ReportDetailsDialog({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final String category = data["category"] ?? "";
    final int? quantity = data["quantity"];
    final String date = data["transaction_date"] ?? data["created_at"] ?? "";
    final String message = data["message"] ?? "";

    // readable category labels
    String categoryLabel = switch (category) {
      "stock_in" => "Stock In",
      "stock_out" => "Stock Out",
      "item" => "New Item",
      "no_stock" => "Low Stock",
      _ => category
    };

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      title: const Text("Report Details"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Category: $categoryLabel"),
          if (quantity != null) Text("Quantity: $quantity"),
          Text("Date: $date"),
          const SizedBox(height: 12),

          const Text("Description:",
              style: TextStyle(fontWeight: FontWeight.bold)),
          Text(message),
        ],
      ),
      actions: [
        TextButton(
          child: const Text("Close"),
          onPressed: () => Navigator.pop(context),
        )
      ],
    );
  }
}
